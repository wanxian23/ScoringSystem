	<br>
	<h3>Tetap Info Pertandingan</h3>
	Tekan:&emsp;<button onclick="btnTetapPertandingan()" id="button1"><b>TETAP</b></button><br><br>
    
    ----------------------------------------------

	<br><br>
	<h3>Tetap Pemenang</h3>
	Tekan:&emsp;<button onclick="btnTetapPemenang()" id="button2"><b>TETAP</b></button>
