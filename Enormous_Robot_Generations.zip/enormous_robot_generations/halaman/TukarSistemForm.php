 <form method="POST" id="form2">
    <label><b>PILIH WARNA-BELAKANG:</b></label>
    <select name="warna" id="warna">
        <option hidden value>------PILIH WARNA------</option>
        <option value="WHITE" id="WHITE">DEFAULT: PUTIH</option>
        <option value="BLACK" id="BLACK">HITAM</option>
        <option value="RED" id="RED">MERAH</option>
        <option value="YELLOW" id="YELLOW">KUNING</option>
    </select>&emsp;
    <input type="submit" name="submit21" value="SUBMIT" form="form2">
 </form>
