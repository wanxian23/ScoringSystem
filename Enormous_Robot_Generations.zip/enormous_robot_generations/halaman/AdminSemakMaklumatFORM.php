<form method="GET">
<h2 style="text-align: center;">MEMERIKSA MAKLUMAT</h2>


<label>&emsp;</label> 
<label>PILIH IDENTITI:</label>
<select name="identiti" style="font-size: 15px;">
	<option value="none">--------------------------------------- PILIH PESERTA ---------------------------------------</option>
	<option value="peserta">Peserta</option>  
	<option value="pengadil">Pengadil</option> 
</select>
<label>&emsp;</label>
<br><br>

<label>&emsp;</label> 
<label>MASUKKAN ID:</label>
<input type="text" name="ID" size="50" placeholder="XXXXXX" autofocus>


<input type="submit" name="semak" value="SEMAK" style="font-size: 15px; width: 100px; margin-left: 20px;">
</form>
